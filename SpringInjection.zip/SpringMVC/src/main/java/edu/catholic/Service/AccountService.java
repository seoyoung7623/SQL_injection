package edu.catholic.Service;

import edu.catholic.mapper.AccountMapper;
import edu.catholic.model.Account;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
public class AccountService {

    private final AccountMapper accountMapper;

    @Autowired
    public AccountService(AccountMapper accountMapper) {
        this.accountMapper = accountMapper;
    }


    @Transactional
    public void insertAccount(Account account) {
        accountMapper.insertAccount(account);
    }

    @Transactional
    public Account getAccount(String id) {
        Account account = accountMapper.getAccount(id);
        return account;
    }
    @Transactional
    public List<Account> getAccountList() {
        List<Account> result = accountMapper.getAccountList();
        return result;
    }
    @Transactional
    public List<Account> sqlInjection(String id, String password) {
        System.out.println("id: " + id + " password: " + password);
        List<Account> result = accountMapper.sqlInjection(id, password);
        return result;
    }
}
